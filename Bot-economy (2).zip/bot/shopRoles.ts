export const SHOP_ROLE_MAP: Record<string, string | string[]> = {
  "XP Boost": "1517343488549716070",
  "Inversionista": "1517344933562810368",
  "Destacado": "1517343616559747235",
  "Ticket Premium": "1517343390100881458",
  "Ticket Plus": "1517343312816640070",
  "Anti-Robo": "1517343204377366609",
  "Ejecutivo": "1517344887614210203",
  "Trabajador": "1517344835114237972",
};
