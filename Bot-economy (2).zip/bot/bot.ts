import {
  Client,
  GatewayIntentBits,
  Events,
  Message,
  EmbedBuilder,
  TextChannel,
  Guild,
  GuildMember,
} from "discord.js";
import { logger } from "../lib/logger";
import { config } from "./config";
import { SHOP_ROLE_MAP } from "./shopRoles";

let client: Client | null = null;

function parseShopEmbed(message: Message): { userId: string; itemName: string; amountSpent: string } | null {
  if (!message.embeds.length) return null;

  for (const embed of message.embeds) {
    const author = (embed.author?.name ?? "").toLowerCase();
    const description = embed.description ?? "";

    const isShopLog =
      author.includes("balance updated") ||
      description.toLowerCase().includes("buy item");

    if (!isShopLog) continue;

    let userId: string | null = null;
    let itemName: string | null = null;
    let amountSpent = "N/A";

    const userMatch = description.match(/\*\*User:\*\*\s*<@!?(\d+)>/i);
    if (userMatch) userId = userMatch[1];

    const amountMatch = description.match(/Cash:\s*`([^`]+)`/i);
    if (amountMatch) amountSpent = amountMatch[1].replace("-", "").trim();

    const reasonMatch = description.match(/buy item\s*\(([^)]+)\)/i);
    if (reasonMatch) itemName = reasonMatch[1].trim();

    if (userId && itemName) return { userId, itemName, amountSpent };
  }

  return null;
}

async function assignRoles(guild: Guild, userId: string, itemName: string) {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member) return { assigned: [], skipped: [], member: null };

  const normalised = itemName.toLowerCase();
  let roleIds: string[] = [];

  for (const [key, value] of Object.entries(SHOP_ROLE_MAP)) {
    if (key.toLowerCase() === normalised) {
      roleIds = Array.isArray(value) ? value : [value];
      break;
    }
  }

  await guild.roles.fetch();

  const assigned: string[] = [];
  const skipped: string[] = [];

  for (const roleId of roleIds) {
    const role = guild.roles.cache.get(roleId);
    if (!role) continue;

    if (member.roles.cache.has(roleId)) {
      skipped.push(role.name);
      continue;
    }

    await member.roles.add(role).then(() => assigned.push(role.name)).catch(() => skipped.push(role.name));
  }

  return { assigned, skipped, member };
}

export async function startBot() {
  client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
  });

  client.on(Events.ClientReady, (c) => {
    c.user.setPresence({
      status: "online",
      activities: [{ name: "Shop Bot", type: 3 }],
    });
  });

  client.on(Events.MessageCreate, async (message) => {
    if (message.channelId !== config.logChannelId) return;
    if (!message.author.bot) return;

    const parsed = parseShopEmbed(message);
    if (!parsed) return;

    const guild = message.guild ?? client?.guilds.cache.get(config.guildId);
    if (!guild) return;

    await assignRoles(guild, parsed.userId, parsed.itemName);
  });

  await client.login(config.token);
}

export async function stopBot() {
  if (client) {
    await client.destroy();
    client = null;
  }
}
