import express from "express";
const app = express();

app.get("/", (_, res) => res.send("Bot online"));

export default app;
