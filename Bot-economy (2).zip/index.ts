import app from "./app";
import { startBot } from "./bot/bot";
import { validateConfig } from "./bot/config";

const port = Number(process.env.PORT || 3000);

app.listen(port, () => {
  console.log("Server running on", port);
});

validateConfig();
startBot();
